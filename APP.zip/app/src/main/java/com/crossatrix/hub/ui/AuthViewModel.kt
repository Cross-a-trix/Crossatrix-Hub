package com.crossatrix.hub.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.crossatrix.hub.data.AuthApi
import com.crossatrix.hub.data.LoginResponse
import com.crossatrix.hub.data.LoginResult
import com.crossatrix.hub.data.SessionManager
import com.crossatrix.hub.data.SessionStore
import com.crossatrix.hub.notify.MessageScheduler
import kotlinx.coroutines.launch

data class LoginUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
)

class AuthViewModel(app: Application) : AndroidViewModel(app) {

    private val store = SessionStore(app)
    private val api = AuthApi()

    /** Current session, or null if logged out / expired. */
    var session: LoginResponse? by mutableStateOf(loadStoredSession())
        private set

    var uiState by mutableStateOf(LoginUiState())
        private set

    /** An expired access token is fine as long as it can be refreshed. */
    private fun loadStoredSession(): LoginResponse? {
        val s = store.load() ?: return null
        val expired = s.expires_at * 1000 <= System.currentTimeMillis()
        if (expired && s.refresh_token.isNullOrBlank()) {
            store.clear()
            return null
        }
        return s
    }

    /** Refreshes the access token if needed; logs out if the refresh token was rejected. */
    fun checkSession() {
        if (session == null) return
        viewModelScope.launch {
            val updated = SessionManager.ensureFresh(getApplication())
            session = updated
            if (updated == null) MessageScheduler.stop(getApplication())
        }
    }

    fun login(identifier: String, password: String, onSuccess: () -> Unit) {
        if (identifier.isBlank() || password.isEmpty()) {
            uiState = LoginUiState(error = "Enter your email/username and password.")
            return
        }
        uiState = LoginUiState(isLoading = true)
        viewModelScope.launch {
            when (val result = api.login(identifier, password)) {
                is LoginResult.Success -> {
                    store.save(result.session)
                    session = result.session
                    MessageScheduler.start(getApplication())
                    uiState = LoginUiState()
                    onSuccess()
                }
                LoginResult.Locked ->
                    uiState = LoginUiState(error = "This account is currently locked.")
                is LoginResult.Failure ->
                    uiState = LoginUiState(error = result.message)
            }
        }
    }

    fun logout() {
        MessageScheduler.stop(getApplication())
        store.clear()
        session = null
    }

    fun clearError() {
        uiState = uiState.copy(error = null)
    }
}
