package com.crossatrix.hub.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

object Api {
    const val BASE_URL = "https://digjxtmzafzcgytgcwmb.supabase.co/functions/v1"
    const val REFRESH_URL = "https://digjxtmzafzcgytgcwmb.supabase.co/auth/v1/token?grant_type=refresh_token"

    // Public "anon" API key of the Crossatrix auth backend (safe to ship in the app).
    const val ANON_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpZ2p4dG16YWZ6Y2d5dGdjd21iIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4MzYyOTksImV4cCI6MjA4OTQxMjI5OX0.Azv9brTysfDScaPWe3svOKbFjym4otbnFwgdup8KDuw"

    val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
}

class AuthApi {

    suspend fun login(identifier: String, password: String): LoginResult =
        withContext(Dispatchers.IO) {
            // The API accepts "email", "username" or "loginname".
            val key = if (identifier.contains("@")) "email" else "username"
            val body = JsonObject(
                mapOf(
                    key to JsonPrimitive(identifier.trim()),
                    "password" to JsonPrimitive(password),
                )
            ).toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("${Api.BASE_URL}/crossatrix-login")
                .post(body)
                .build()

            try {
                Api.client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    when {
                        response.isSuccessful -> {
                            try {
                                LoginResult.Success(Api.json.decodeFromString<LoginResponse>(text))
                            } catch (e: Exception) {
                                LoginResult.Failure("Unexpected server response.")
                            }
                        }
                        response.code == 423 -> LoginResult.Locked
                        else -> {
                            val err = runCatching {
                                Api.json.decodeFromString<ErrorResponse>(text)
                            }.getOrNull()
                            val msg = when (response.code) {
                                401 -> "Invalid credentials."
                                404 -> "Service is currently unavailable."
                                else -> err?.error ?: "Login failed (HTTP ${response.code})."
                            }
                            LoginResult.Failure(msg)
                        }
                    }
                }
            } catch (e: IOException) {
                LoginResult.Failure("Network error. Check your connection.")
            }
        }

    /** Exchanges a refresh token for a new access token (and a new refresh token). */
    suspend fun refresh(refreshToken: String): RefreshResult = withContext(Dispatchers.IO) {
        val body = JsonObject(mapOf("refresh_token" to JsonPrimitive(refreshToken)))
            .toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(Api.REFRESH_URL)
            .header("apikey", Api.ANON_KEY)
            .post(body)
            .build()
        try {
            Api.client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                when {
                    response.isSuccessful -> {
                        val r = runCatching { Api.json.decodeFromString<RefreshResponse>(text) }.getOrNull()
                            ?: return@withContext RefreshResult.Failure("Unexpected server response.")
                        val expiresAt = r.expires_at
                            ?: r.expires_in?.let { System.currentTimeMillis() / 1000 + it }
                            ?: (System.currentTimeMillis() / 1000 + 3600)
                        RefreshResult.Success(r.access_token, r.refresh_token, expiresAt)
                    }
                    // Refresh token unknown, expired or already used.
                    response.code == 400 || response.code == 401 || response.code == 403 ->
                        RefreshResult.Invalid
                    else -> RefreshResult.Failure("Refresh failed (HTTP ${response.code}).")
                }
            }
        } catch (e: IOException) {
            RefreshResult.Failure("Network error.")
        }
    }
}
