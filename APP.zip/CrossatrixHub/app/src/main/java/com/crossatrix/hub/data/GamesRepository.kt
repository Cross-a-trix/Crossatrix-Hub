package com.crossatrix.hub.data

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.builtins.ListSerializer

data class CachedGames(val games: List<Game>, val utcDay: Long)

/**
 * Top games are cached on the device and only fetched again once per UTC day
 * (the cache expires at 00:00 UTC). If a fetch fails, the old cache is used.
 */
object GamesRepository {
    private const val PREFS = "games_cache"
    private const val KEY_JSON = "json"
    private const val KEY_DAY = "utc_day"
    private const val MS_PER_DAY = 86_400_000L

    private val mutex = Mutex()

    /** Days since 1970-01-01 in UTC; changes at 00:00 UTC. */
    private fun todayUtc(): Long = System.currentTimeMillis() / MS_PER_DAY

    fun cached(context: Context): CachedGames? {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_JSON, null) ?: return null
        val day = prefs.getLong(KEY_DAY, -1L)
        val games = runCatching {
            Api.json.decodeFromString(ListSerializer(Game.serializer()), json)
        }.getOrNull() ?: return null
        return CachedGames(games, day)
    }

    private fun save(context: Context, games: List<Game>) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_JSON, Api.json.encodeToString(ListSerializer(Game.serializer()), games))
            .putLong(KEY_DAY, todayUtc())
            .apply()
    }

    /** True if the cache was fetched on the current UTC day. */
    fun isFresh(cache: CachedGames?): Boolean = cache != null && cache.utcDay == todayUtc()

    /**
     * Returns today's games from the cache, or fetches them if the cache is from an earlier
     * UTC day. Returns the old cache if the fetch fails, or null if there is nothing at all.
     */
    suspend fun get(context: Context): List<Game>? = mutex.withLock {
        val cache = cached(context)
        if (isFresh(cache)) return cache!!.games

        val fetched = GamesApi.fetch()
        if (fetched != null && fetched.isNotEmpty()) {
            save(context, fetched)
            return fetched
        }
        // Fetch failed (or came back empty): keep showing the old list if we have one.
        cache?.games ?: fetched
    }
}
