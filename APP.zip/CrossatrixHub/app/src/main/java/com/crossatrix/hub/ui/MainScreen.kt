package com.crossatrix.hub.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.viewmodel.compose.viewModel
import com.crossatrix.hub.R
import com.crossatrix.hub.data.LoginResponse

private const val TAB_HOME = 0
private const val TAB_GAMES = 1

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    session: LoginResponse,
    onOpenUrl: (title: String, url: String) -> Unit,
    onLogout: () -> Unit,
    gamesViewModel: GamesViewModel = viewModel(),
) {
    var tab by rememberSaveable { mutableIntStateOf(TAB_HOME) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (tab == TAB_HOME) "Crossatrix Hub" else "Top Games") },
                actions = {
                    if (tab == TAB_HOME) TextButton(onClick = onLogout) { Text("Log out") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        bottomBar = {
            NavigationBar {
                val colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                NavigationBarItem(
                    selected = tab == TAB_HOME,
                    onClick = { tab = TAB_HOME },
                    icon = { Icon(painterResource(R.drawable.ic_tab_home), contentDescription = null) },
                    label = { Text("Home") },
                    colors = colors,
                )
                NavigationBarItem(
                    selected = tab == TAB_GAMES,
                    onClick = { tab = TAB_GAMES },
                    icon = { Icon(painterResource(R.drawable.ic_tab_games), contentDescription = null) },
                    label = { Text("Games") },
                    colors = colors,
                )
            }
        },
    ) { padding ->
        when (tab) {
            TAB_GAMES -> GamesTab(
                viewModel = gamesViewModel,
                onOpenGame = { game -> onOpenUrl(game.name, game.url) },
                modifier = Modifier.padding(padding),
            )
            else -> HomeTab(
                session = session,
                onOpenApp = { app -> onOpenUrl(app.name, app.url) },
                modifier = Modifier.padding(padding),
            )
        }
    }
}
