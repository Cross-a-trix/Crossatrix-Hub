package com.crossatrix.hub.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.crossatrix.hub.notify.MessagePrefs
import kotlin.math.roundToInt

@Composable
fun MessageIntervalCard() {
    val ctx = LocalContext.current
    val prefs = remember { MessagePrefs(ctx) }
    val choices = MessagePrefs.CHOICES
    var index by remember {
        mutableFloatStateOf(choices.indexOf(prefs.intervalMinutes).coerceAtLeast(0).toFloat())
    }
    val minutes = choices[index.roundToInt()]

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Message checks", style = MaterialTheme.typography.titleMedium)
            Text(
                "How often the app looks for new messages.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                if (minutes == 1) "Every minute" else if (minutes == 60) "Every hour" else "Every $minutes minutes",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 12.dp),
            )
            Slider(
                value = index,
                onValueChange = { index = it },
                // Saved when you let go, so the checking restarts only once.
                onValueChangeFinished = { prefs.intervalMinutes = choices[index.roundToInt()] },
                valueRange = 0f..(choices.size - 1).toFloat(),
                steps = choices.size - 2,
            )
            Text(
                "Standard: every ${MessagePrefs.DEFAULT_MINUTES} minutes. Shorter intervals use more battery.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
