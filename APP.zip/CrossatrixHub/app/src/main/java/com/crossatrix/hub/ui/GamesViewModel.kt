package com.crossatrix.hub.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.crossatrix.hub.data.Game
import com.crossatrix.hub.data.GamesRepository
import kotlinx.coroutines.launch

sealed interface GamesState {
    data object Loading : GamesState
    data object Error : GamesState
    data class Success(val games: List<Game>) : GamesState
}

class GamesViewModel(app: Application) : AndroidViewModel(app) {
    // Show the cached list immediately, before anything is fetched.
    var state: GamesState by mutableStateOf(
        GamesRepository.cached(app)?.let { GamesState.Success(it.games) } ?: GamesState.Loading
    )
        private set
    var isRefreshing by mutableStateOf(false)
        private set

    init {
        load()
    }

    /** Loads the games: from the cache if it is from today (UTC), otherwise from the server. */
    fun load(refresh: Boolean = false) {
        viewModelScope.launch {
            val hadData = state is GamesState.Success
            if (refresh) isRefreshing = true else if (!hadData) state = GamesState.Loading
            val result = GamesRepository.get(getApplication())
            when {
                result != null -> state = GamesState.Success(result)
                hadData -> Unit // keep what is on screen
                else -> state = GamesState.Error
            }
            isRefreshing = false
        }
    }
}
