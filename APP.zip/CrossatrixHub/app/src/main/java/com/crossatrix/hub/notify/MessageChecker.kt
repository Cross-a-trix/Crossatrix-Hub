package com.crossatrix.hub.notify

import android.content.Context
import com.crossatrix.hub.data.MessageApi
import com.crossatrix.hub.data.SessionStore
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** One check of the messages API; shared by the 2-minute service and the WorkManager backup. */
object MessageChecker {
    private const val PREFS = "message_state"
    private const val KEY_LAST = "last_keys"
    private const val KEY_LAST_CHECK = "last_check_ms"
    private val mutex = Mutex()

    /**
     * @param onlyIfDue skip the check if the last one was less than the chosen interval ago
     * (used by the 15-minute backup worker so it respects longer intervals).
     */
    suspend fun check(context: Context, onlyIfDue: Boolean = false) {
        mutex.withLock {
            val ctx = context.applicationContext
            val statePrefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            if (onlyIfDue) {
                val intervalMs = MessagePrefs(ctx).intervalMinutes * 60_000L
                val last = statePrefs.getLong(KEY_LAST_CHECK, 0L)
                if (now - last < intervalMs * 9 / 10) return
            }
            statePrefs.edit().putLong(KEY_LAST_CHECK, now).apply()
            val session = SessionStore(ctx).load() ?: return

            // If notifications are blocked, don't consume messages: try again next time.
            if (!MessageNotifier.canNotify(ctx)) return

            val messages = MessageApi.fetch(session.user.id) ?: return

            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val previous = prefs.getStringSet(KEY_LAST, emptySet()).orEmpty()
            val base = System.nanoTime().toInt()

            // One notification per message object that wasn't in the previous fetch.
            messages.filter { it.key !in previous }.forEachIndexed { i, msg ->
                MessageNotifier.show(ctx, msg, base + i)
            }

            prefs.edit().putStringSet(KEY_LAST, messages.map { it.key }.toSet()).apply()
        }
    }

    fun clearState(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
