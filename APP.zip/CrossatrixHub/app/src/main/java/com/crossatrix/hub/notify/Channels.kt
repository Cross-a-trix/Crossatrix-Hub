package com.crossatrix.hub.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

/**
 * Creates every notification channel up front, so they all appear in
 * Settings > Apps > Crossatrix Hub > Notifications as soon as the app runs.
 *
 * Android does not let an app change a channel's sound after it was created, so the
 * message channel's id includes the chosen sound: picking a new sound creates a new
 * channel and removes the old one.
 */
object Channels {
    const val BACKGROUND = "background_checks"
    const val SIDEBAR = "sidebar"
    private const val MESSAGES_PREFIX = "messages"

    fun messagesChannelId(context: Context): String =
        MESSAGES_PREFIX + "_" + Integer.toHexString(MessagePrefs(context).soundKey.hashCode())

    /** The chosen message sound, or null for silent. */
    fun soundUri(context: Context): Uri? = when (val key = MessagePrefs(context).soundKey) {
        MessagePrefs.SOUND_SILENT -> null
        MessagePrefs.SOUND_DEFAULT -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        else -> Uri.parse(key)
    }

    fun createAll(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)

        val messagesId = messagesChannelId(context)
        val messages = NotificationChannel(messagesId, "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "New messages from Crossatrix"
            enableVibration(true)
            setShowBadge(true)
            val uri = soundUri(context)
            if (uri == null) {
                setSound(null, null)
            } else {
                setSound(
                    uri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
            }
        }
        nm.createNotificationChannel(messages)

        // Remove message channels made for a previously chosen sound.
        nm.notificationChannels
            .filter { it.id.startsWith(MESSAGES_PREFIX) && it.id != messagesId }
            .forEach { nm.deleteNotificationChannel(it.id) }

        nm.createNotificationChannel(
            NotificationChannel(BACKGROUND, "Background checks", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Silent entry shown while Crossatrix Hub checks for messages"
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(SIDEBAR, "Crossi sidebar", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Silent entry shown while the Crossi sidebar is on"
                setShowBadge(false)
            },
        )
    }
}
