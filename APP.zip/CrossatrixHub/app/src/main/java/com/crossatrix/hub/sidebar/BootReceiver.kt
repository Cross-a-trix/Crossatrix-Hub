package com.crossatrix.hub.sidebar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.crossatrix.hub.data.SessionStore
import com.crossatrix.hub.notify.MessageScheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        SidebarController.apply(context)
        if (SessionStore(context).load() != null) MessageScheduler.start(context)
    }
}
