package com.crossatrix.hub.sidebar

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class SidebarPrefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("sidebar", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) = p.edit().putBoolean("enabled", v).apply()

    var side: Int
        get() = p.getInt("side", SIDE_RIGHT)
        set(v) = p.edit().putInt("side", v).apply()

    /** Package names of the device apps shown in the sidebar, in the order they were picked. */
    var apps: List<String>
        get() = p.getString("apps", "").orEmpty().split("\n").filter { it.isNotBlank() }
        set(v) = p.edit().putString("apps", v.joinToString("\n")).apply()

    companion object {
        const val SIDE_LEFT = 0
        const val SIDE_RIGHT = 1
    }
}

object SidebarController {
    /** Starts or stops the overlay service to match the saved setting + permission. */
    fun apply(context: Context) {
        val intent = Intent(context, SidebarService::class.java)
        if (SidebarPrefs(context).enabled && Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, intent)
        } else {
            context.stopService(intent)
        }
    }
}
