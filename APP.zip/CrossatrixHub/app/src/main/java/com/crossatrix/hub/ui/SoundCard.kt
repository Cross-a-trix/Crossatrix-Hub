package com.crossatrix.hub.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.crossatrix.hub.data.HubMessage
import com.crossatrix.hub.notify.Channels
import com.crossatrix.hub.notify.MessageNotifier
import com.crossatrix.hub.notify.MessagePrefs

private fun soundTitle(ctx: Context, key: String): String = when (key) {
    MessagePrefs.SOUND_SILENT -> "Silent"
    MessagePrefs.SOUND_DEFAULT -> {
        val name = runCatching {
            RingtoneManager.getRingtone(ctx, Settings.System.DEFAULT_NOTIFICATION_URI)?.getTitle(ctx)
        }.getOrNull()
        if (name != null) "Default ($name)" else "Default"
    }
    else -> runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(key))?.getTitle(ctx) }
        .getOrNull() ?: "Custom sound"
}

@Composable
fun SoundCard() {
    val ctx = LocalContext.current
    val prefs = remember { MessagePrefs(ctx) }
    var key by remember { mutableStateOf(prefs.soundKey) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            val newKey = when {
                uri == null -> MessagePrefs.SOUND_SILENT
                uri == Settings.System.DEFAULT_NOTIFICATION_URI -> MessagePrefs.SOUND_DEFAULT
                else -> uri.toString()
            }
            prefs.soundKey = newKey
            key = newKey
            Channels.createAll(ctx) // switches to a channel with the new sound
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Notification sound", style = MaterialTheme.typography.titleMedium)
            Text(
                "Sound for new messages.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                soundTitle(ctx, key),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val existing: Uri? = when (key) {
                        MessagePrefs.SOUND_SILENT -> null
                        MessagePrefs.SOUND_DEFAULT -> Settings.System.DEFAULT_NOTIFICATION_URI
                        else -> Uri.parse(key)
                    }
                    picker.launch(
                        Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Message sound")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
                        },
                    )
                }) { Text("Choose sound") }

                TextButton(onClick = {
                    MessageNotifier.show(
                        ctx,
                        HubMessage("This is a test notification.", "Crossatrix Hub", "test-${System.nanoTime()}"),
                        System.nanoTime().toInt(),
                    )
                }) { Text("Send test") }
            }
            Text(
                "If you change vibration or pop-up settings in Android's notification settings, they reset when you pick a new sound here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}
