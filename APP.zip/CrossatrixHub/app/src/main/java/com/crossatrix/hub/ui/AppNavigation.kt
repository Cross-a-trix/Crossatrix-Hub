package com.crossatrix.hub.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

object Routes {
    const val LOGIN = "login"
    const val MENU = "menu"
    const val APPS = "apps"
    const val WEB = "web"
}

@Composable
fun AppNavigation(authViewModel: AuthViewModel = viewModel()) {
    val navController = rememberNavController()
    val startDestination = remember {
        if (authViewModel.session != null) Routes.MENU else Routes.LOGIN
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.LOGIN) {
            LoginScreen(
                state = authViewModel.uiState,
                onLogin = { id, pw ->
                    authViewModel.login(id, pw) {
                        navController.navigate(Routes.MENU) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    }
                },
                onInputChanged = authViewModel::clearError,
            )
        }
        composable(Routes.MENU) {
            val session = authViewModel.session
            if (session != null) {
                MenuScreen(
                    session = session,
                    onOpenSection = { route -> navController.navigate(route) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(Routes.MENU) { inclusive = true }
                        }
                    },
                )
            }
        }
        composable(Routes.APPS) {
            AppsScreen(
                onBack = { navController.popBackStack() },
                onOpenApp = { app -> navController.navigate("${Routes.WEB}/${app.id}") },
            )
        }
        composable(
            route = "${Routes.WEB}/{appId}",
            arguments = listOf(navArgument("appId") { type = NavType.StringType }),
        ) { entry ->
            val app = HubApps.byId(entry.arguments?.getString("appId"))
            if (app != null) {
                WebViewScreen(app = app, onClose = { navController.popBackStack() })
            }
        }
    }
}
