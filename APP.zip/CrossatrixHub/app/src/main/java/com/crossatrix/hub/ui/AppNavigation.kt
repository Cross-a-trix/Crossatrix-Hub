package com.crossatrix.hub.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.crossatrix.hub.data.SessionManager
import kotlinx.coroutines.launch

/** Something to open in the in-app browser: either a Crossi app (by id) or a plain URL. */
data class OpenRequest(val title: String, val url: String?, val appId: String?)

object Routes {
    const val LOGIN = "login"
    const val MAIN = "main"
    const val WEB = "web"
    const val OPTIONS = "options"
    const val APP_PICKER = "app_picker"
}

@Composable
fun AppNavigation(
    pendingOpen: OpenRequest? = null,
    onPendingConsumed: () -> Unit = {},
    authViewModel: AuthViewModel = viewModel(),
) {
    val navController = rememberNavController()
    val startDestination = remember {
        if (authViewModel.session != null) Routes.MAIN else Routes.LOGIN
    }

    // Page currently opened in the in-app browser (apps and games share one screen).
    var webTitle by rememberSaveable { mutableStateOf("") }
    var webUrl by rememberSaveable { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun openWeb(title: String, url: String) {
        webTitle = title
        webUrl = url
        navController.navigate(Routes.WEB) { launchSingleTop = true }
    }

    /** Opens a Crossi app; apps with auto login get a fresh access token + email in the URL. */
    suspend fun openApp(app: HubApp) {
        val session = SessionManager.ensureFresh(context)
        openWeb(app.name, app.launchUrl(session?.access_token, session?.user?.email))
    }

    // Refresh the login whenever the app comes to the foreground.
    LifecycleEventEffect(Lifecycle.Event.ON_START) { authViewModel.checkSession() }

    // If the session ends (refresh token rejected), go back to the login screen.
    LaunchedEffect(authViewModel.session) {
        if (authViewModel.session == null &&
            navController.currentDestination?.route != Routes.LOGIN
        ) {
            navController.navigate(Routes.LOGIN) {
                popUpTo(0)
                launchSingleTop = true
            }
        }
    }

    // A page requested from the sidebar overlay.
    LaunchedEffect(pendingOpen) {
        val request = pendingOpen
        if (request != null) {
            if (authViewModel.session != null) {
                val app = HubApps.byId(request.appId)
                when {
                    app != null -> openApp(app)
                    request.url != null -> openWeb(request.title, request.url)
                }
            }
            onPendingConsumed()
        }
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.LOGIN) {
            LoginScreen(
                state = authViewModel.uiState,
                onLogin = { id, pw ->
                    authViewModel.login(id, pw) {
                        navController.navigate(Routes.MAIN) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    }
                },
                onInputChanged = authViewModel::clearError,
            )
        }
        composable(Routes.MAIN) {
            val session = authViewModel.session
            if (session != null) {
                RequestNotificationPermission()
                MainScreen(
                    session = session,
                    onOpenApp = { app -> scope.launch { openApp(app) } },
                    onOpenUrl = { title, url -> openWeb(title, url) },
                    onOpenOptions = { navController.navigate(Routes.OPTIONS) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(Routes.MAIN) { inclusive = true }
                        }
                    },
                )
            }
        }
        composable(Routes.OPTIONS) {
            OptionsScreen(
                onBack = { navController.popBackStack() },
                onChooseApps = { navController.navigate(Routes.APP_PICKER) },
            )
        }
        composable(Routes.APP_PICKER) {
            AppPickerScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.WEB) {
            if (webUrl.isBlank()) {
                LaunchedEffect(Unit) { navController.popBackStack() }
            } else {
                // key() reloads the page when a different URL is requested while this screen is open.
                key(webUrl) {
                    WebViewScreen(
                        title = webTitle,
                        url = webUrl,
                        onClose = { navController.popBackStack() },
                    )
                }
            }
        }
    }
}
