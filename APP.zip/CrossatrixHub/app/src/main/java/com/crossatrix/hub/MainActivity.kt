package com.crossatrix.hub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.crossatrix.hub.ui.AppNavigation
import com.crossatrix.hub.ui.theme.CrossatrixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CrossatrixTheme {
                AppNavigation()
            }
        }
    }
}
