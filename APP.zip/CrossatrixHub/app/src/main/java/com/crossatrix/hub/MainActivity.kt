package com.crossatrix.hub

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.crossatrix.hub.data.SessionStore
import com.crossatrix.hub.notify.MessageScheduler
import com.crossatrix.hub.ui.AppNavigation
import com.crossatrix.hub.ui.theme.CrossatrixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Dark background -> always use light system bar icons.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            CrossatrixTheme {
                AppNavigation()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Check for messages every time the app is opened, and keep the 15-min check scheduled.
        if (SessionStore(this).load() != null) MessageScheduler.start(this)
    }
}
