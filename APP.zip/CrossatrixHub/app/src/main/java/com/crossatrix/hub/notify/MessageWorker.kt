package com.crossatrix.hub.notify

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Backup check (every 15 min) in case the 2-minute service was stopped by the system. */
class MessageWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        MessageChecker.check(applicationContext)
        return Result.success()
    }
}

object MessageScheduler {
    private const val PERIODIC = "message_poll"
    private const val NOW = "message_check_now"

    private val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    /**
     * Starts the 2-minute checking service, checks once right now, and keeps the
     * 15-minute backup scheduled.
     */
    fun start(context: Context) {
        runCatching {
            ContextCompat.startForegroundService(context, Intent(context, MessagePollService::class.java))
        }
        val wm = WorkManager.getInstance(context)
        wm.enqueueUniquePeriodicWork(
            PERIODIC,
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MessageWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build(),
        )
        wm.enqueueUniqueWork(
            NOW,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<MessageWorker>()
                .setConstraints(constraints)
                .build(),
        )
    }

    fun stop(context: Context) {
        context.stopService(Intent(context, MessagePollService::class.java))
        val wm = WorkManager.getInstance(context)
        wm.cancelUniqueWork(PERIODIC)
        wm.cancelUniqueWork(NOW)
        MessageChecker.clearState(context)
    }
}
