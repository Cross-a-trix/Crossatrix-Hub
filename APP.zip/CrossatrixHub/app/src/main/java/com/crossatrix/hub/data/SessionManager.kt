package com.crossatrix.hub.data

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Keeps the stored session valid. Refresh tokens are single-use, so every refresh
 * goes through one lock and re-reads the stored session first.
 */
object SessionManager {
    private val mutex = Mutex()
    private const val SKEW_SECONDS = 60L

    /**
     * Returns the stored session with a valid access token, refreshing it if it is
     * expired (or about to). Returns null if there is no session or the refresh token
     * was rejected (the session is cleared then). If only the network failed, the
     * old session is returned so the user stays signed in.
     */
    suspend fun ensureFresh(context: Context): LoginResponse? {
        mutex.withLock {
            val store = SessionStore(context)
            val session = store.load() ?: return null
            val now = System.currentTimeMillis() / 1000
            if (session.expires_at - SKEW_SECONDS > now) return session

            val refreshToken = session.refresh_token
            if (refreshToken.isNullOrBlank()) {
                store.clear()
                return null
            }
            return when (val result = AuthApi().refresh(refreshToken)) {
                is RefreshResult.Success -> {
                    val updated = session.copy(
                        access_token = result.accessToken,
                        refresh_token = result.refreshToken ?: refreshToken,
                        expires_at = result.expiresAt,
                    )
                    store.save(updated)
                    updated
                }
                RefreshResult.Invalid -> {
                    store.clear()
                    null
                }
                is RefreshResult.Failure -> session
            }
        }
    }

    /** Access token for authenticated Crossatrix calls (Authorization: Bearer ...). */
    suspend fun validAccessToken(context: Context): String? = ensureFresh(context)?.access_token
}
