package com.crossatrix.hub.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.crossatrix.hub.sidebar.SidebarController
import com.crossatrix.hub.sidebar.SidebarPrefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionsScreen(
    onBack: () -> Unit,
    onChooseApps: () -> Unit,
) {
    val ctx = LocalContext.current
    val prefs = remember { SidebarPrefs(ctx) }
    var enabled by remember { mutableStateOf(prefs.enabled && Settings.canDrawOverlays(ctx)) }
    var side by remember { mutableIntStateOf(prefs.side) }
    var pendingEnable by remember { mutableStateOf(false) }
    val appCount = remember { prefs.apps.size }

    fun setEnabled(value: Boolean) {
        enabled = value
        prefs.enabled = value
        SidebarController.apply(ctx)
    }

    // Coming back from the system "Display over other apps" screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        if (pendingEnable) {
            pendingEnable = false
            if (Settings.canDrawOverlays(ctx)) setEnabled(true)
        } else if (enabled && !Settings.canDrawOverlays(ctx)) {
            setEnabled(false)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Options") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Crossi sidebar", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Swipe from the screen edge, in any app, to open a drawer with your Crossi apps, balance and favourite apps.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                        Switch(
                            checked = enabled,
                            onCheckedChange = { on ->
                                when {
                                    !on -> setEnabled(false)
                                    Settings.canDrawOverlays(ctx) -> setEnabled(true)
                                    else -> {
                                        // Needs the "Display over other apps" permission first.
                                        pendingEnable = true
                                        ctx.startActivity(
                                            Intent(
                                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                Uri.parse("package:${ctx.packageName}"),
                                            ),
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.padding(start = 12.dp),
                        )
                    }
                    if (!Settings.canDrawOverlays(ctx)) {
                        Text(
                            "Turning this on opens a system screen where you allow “Display over other apps” for Crossatrix Hub.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }
            }

            if (enabled) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Screen edge", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = side == SidebarPrefs.SIDE_LEFT,
                                onClick = {
                                    side = SidebarPrefs.SIDE_LEFT
                                    prefs.side = side
                                    SidebarController.apply(ctx)
                                },
                                label = { Text("Left") },
                            )
                            FilterChip(
                                selected = side == SidebarPrefs.SIDE_RIGHT,
                                onClick = {
                                    side = SidebarPrefs.SIDE_RIGHT
                                    prefs.side = side
                                    SidebarController.apply(ctx)
                                },
                                label = { Text("Right") },
                            )
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onChooseApps),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Sidebar apps", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (appCount == 0) "Choose which apps from your device appear in the sidebar"
                            else "$appCount selected · tap to change",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
            }
        }
    }
}
