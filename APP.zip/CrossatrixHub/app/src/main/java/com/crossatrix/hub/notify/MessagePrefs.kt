package com.crossatrix.hub.notify

import android.content.Context
import android.content.SharedPreferences

class MessagePrefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("message_settings", Context.MODE_PRIVATE)

    /** How often the app checks for messages, in minutes. */
    var intervalMinutes: Int
        get() = p.getInt(KEY_INTERVAL, DEFAULT_MINUTES).let { if (it in CHOICES) it else DEFAULT_MINUTES }
        set(v) = p.edit().putInt(KEY_INTERVAL, v).apply()

    /** "default", "silent", or the URI of the chosen sound. */
    var soundKey: String
        get() = p.getString(KEY_SOUND, SOUND_DEFAULT) ?: SOUND_DEFAULT
        set(v) = p.edit().putString(KEY_SOUND, v).apply()

    fun register(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        p.registerOnSharedPreferenceChangeListener(l)

    fun unregister(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        p.unregisterOnSharedPreferenceChangeListener(l)

    companion object {
        private const val KEY_INTERVAL = "interval_minutes"
        private const val KEY_SOUND = "sound"
        const val SOUND_DEFAULT = "default"
        const val SOUND_SILENT = "silent"
        const val DEFAULT_MINUTES = 3
        val CHOICES = listOf(1, 2, 3, 5, 10, 15, 30, 60)
    }
}
