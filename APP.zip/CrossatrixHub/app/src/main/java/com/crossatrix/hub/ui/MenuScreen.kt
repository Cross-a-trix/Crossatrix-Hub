package com.crossatrix.hub.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.crossatrix.hub.R
import com.crossatrix.hub.data.LoginResponse
import java.text.NumberFormat

private data class MenuSection(
    val title: String,
    @DrawableRes val icon: Int,
    val route: String,
)

private val sections = listOf(
    MenuSection("Crossatrix Apps", R.drawable.app_crossatrix_dashboard, Routes.APPS),
    // More sections will be added here.
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    session: LoginResponse,
    onOpenSection: (String) -> Unit,
    onLogout: () -> Unit,
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Crossatrix Hub") },
                actions = { TextButton(onClick = onLogout) { Text("Log out") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Signed in as", style = MaterialTheme.typography.labelMedium)
                    Text(
                        session.user.email ?: session.user.id,
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Balance: ", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            NumberFormat.getInstance().format(session.croins_balance) + " ¢",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                sections.forEach { section ->
                    Column(
                        modifier = Modifier
                            .clip(MaterialTheme.shapes.large)
                            .clickable { onOpenSection(section.route) }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(
                            shape = CircleShape,
                            border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary),
                            shadowElevation = 4.dp,
                            modifier = Modifier.size(100.dp),
                        ) {
                            Image(
                                painter = painterResource(section.icon),
                                contentDescription = section.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(3.dp)
                                    .clip(CircleShape),
                            )
                        }
                        Text(
                            section.title,
                            style = MaterialTheme.typography.titleSmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .size(width = 100.dp, height = 40.dp),
                        )
                    }
                }
            }
        }
    }
}
