package com.crossatrix.hub.ui

import android.net.Uri
import androidx.annotation.DrawableRes
import com.crossatrix.hub.R

data class HubApp(
    val id: String,
    val name: String,
    val url: String,
    @DrawableRes val icon: Int,
    /** Path that accepts ?access_token=...&email=... for auto login (null = no auto login). */
    val autoLoginPath: String? = null,
) {
    /** The URL to open: with auto-login parameters when the app supports it and we have a session. */
    fun launchUrl(accessToken: String?, email: String?): String {
        val path = autoLoginPath
        if (path == null || accessToken.isNullOrBlank() || email.isNullOrBlank()) return url
        return url.trimEnd('/') + path +
            "?access_token=" + Uri.encode(accessToken) +
            "&email=" + Uri.encode(email)
    }
}

object HubApps {
    /** Apps visible only to specific accounts, matched case-insensitively by email. */
    private val restricted = listOf(
        "cross.a.trix.owner@hotmail.com" to HubApp(
            "update-hub", "UpdateHub", "https://tinyurl.com/crossiupdate", R.drawable.app_update_hub,
        ),
    )

    private val base = listOf(
        HubApp("cross-chat", "Cross Chat", "https://cross-a-chat.lovable.app", R.drawable.app_cross_chat, autoLoginPath = "/auth"),
        HubApp("crossi-ai", "Crossi AI", "https://cross-a-ai.lovable.app", R.drawable.app_crossi_ai, autoLoginPath = "/auth"),
        HubApp("crossi-search", "Crossi Search", "https://crossisearch.lovable.app", R.drawable.app_crossi_search, autoLoginPath = "/auth"),
        HubApp("dashboard", "Crossatrix Dashboard", "https://crossatrix.lovable.app", R.drawable.app_crossatrix_dashboard, autoLoginPath = "/"),
        HubApp("crossi-games", "Crossi Games", "https://crossigames.lovable.app", R.drawable.app_crossi_games, autoLoginPath = "/auth"),
        HubApp("crossi-cloud", "Crossi Cloud", "https://crossicloud.lovable.app", R.drawable.app_crossi_cloud),
        HubApp("crosssino", "Crosssino", "https://crosssino.lovable.app", R.drawable.app_crosssino, autoLoginPath = "/login"),
    )

    /** The base apps, plus any extra apps unlocked for this account's email. */
    fun forEmail(email: String?): List<HubApp> {
        if (email.isNullOrBlank()) return base
        val extra = restricted.filter { it.first.equals(email, ignoreCase = true) }.map { it.second }
        return base + extra
    }

    val all: List<HubApp> get() = base + restricted.map { it.second }

    fun byId(id: String?): HubApp? = all.firstOrNull { it.id == id }
}

/** Hosts that may receive the login token in a URL (the token is never sent anywhere else). */
private val LOGIN_HOSTS = setOf("crossigames.lovable.app")

/**
 * Adds ?access_token=...&email=... to a game URL so the Crossi Games site logs the user in.
 * Only done for https URLs on a trusted Crossi host; any other URL is returned unchanged.
 */
fun addGameLoginParams(url: String, accessToken: String?, email: String?): String {
    if (accessToken.isNullOrBlank() || email.isNullOrBlank()) return url
    val uri = Uri.parse(url)
    if (uri.scheme != "https" || uri.host !in LOGIN_HOSTS) return url
    return uri.buildUpon()
        .appendQueryParameter("access_token", accessToken)
        .appendQueryParameter("email", email)
        .build()
        .toString()
}
