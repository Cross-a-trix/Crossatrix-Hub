package com.crossatrix.hub.ui

import android.net.Uri
import androidx.annotation.DrawableRes
import com.crossatrix.hub.R

data class HubApp(
    val id: String,
    val name: String,
    val url: String,
    @DrawableRes val icon: Int,
    /** Path that accepts ?access_token=...&email=... for auto login (null = no auto login). */
    val autoLoginPath: String? = null,
) {
    /** The URL to open: with auto-login parameters when the app supports it and we have a session. */
    fun launchUrl(accessToken: String?, email: String?): String {
        val path = autoLoginPath
        if (path == null || accessToken.isNullOrBlank() || email.isNullOrBlank()) return url
        return url.trimEnd('/') + path +
            "?access_token=" + Uri.encode(accessToken) +
            "&email=" + Uri.encode(email)
    }
}

object HubApps {
    val all = listOf(
        HubApp("cross-chat", "Cross Chat", "https://cross-a-chat.lovable.app", R.drawable.app_cross_chat, autoLoginPath = "/auth"),
        HubApp("crossi-ai", "Crossi AI", "https://cross-a-ai.lovable.app", R.drawable.app_crossi_ai, autoLoginPath = "/auth"),
        HubApp("crossi-search", "Crossi Search", "https://crossisearch.lovable.app", R.drawable.app_crossi_search, autoLoginPath = "/auth"),
        HubApp("dashboard", "Crossatrix Dashboard", "https://crossatrix.lovable.app", R.drawable.app_crossatrix_dashboard, autoLoginPath = "/"),
        HubApp("crossi-games", "Crossi Games", "https://crossigames.lovable.app", R.drawable.app_crossi_games, autoLoginPath = "/auth"),
        HubApp("crosssino", "Crosssino", "https://crosssino.lovable.app", R.drawable.app_crosssino, autoLoginPath = "/login"),
    )

    fun byId(id: String?): HubApp? = all.firstOrNull { it.id == id }
}
