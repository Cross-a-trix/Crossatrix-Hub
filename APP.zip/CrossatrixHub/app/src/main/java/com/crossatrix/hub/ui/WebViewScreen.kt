package com.crossatrix.hub.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** State that outlives individual WebView callbacks. */
private class WebHolder {
    var fileCallback: ValueCallback<Array<Uri>>? = null
    var permissionRequest: PermissionRequest? = null
    var customView: View? = null
    var customCallback: WebChromeClient.CustomViewCallback? = null
}

/** Pages on these hosts may use the camera and microphone (after the user allows it in Android). */
private fun isTrustedHost(host: String?): Boolean =
    host != null && (host.endsWith(".lovable.app") || host == "lovable.app")

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(title: String, url: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val holder = remember { WebHolder() }

    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var isFullscreen by remember { mutableStateOf(false) }

    fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun exitFullscreen() {
        val view = holder.customView ?: return
        activity?.let { act ->
            (act.window.decorView as ViewGroup).removeView(view)
            WindowCompat.getInsetsController(act.window, act.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
        }
        holder.customView = null
        holder.customCallback?.onCustomViewHidden()
        holder.customCallback = null
        isFullscreen = false
    }

    // ---- File uploads (<input type="file">)
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = holder.fileCallback
        holder.fileCallback = null
        callback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
    }

    // ---- Camera / microphone permission for the page
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val request = holder.permissionRequest
        holder.permissionRequest = null
        if (request != null) {
            val allowed = request.resources.filter { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                    else -> false
                }
            }
            if (allowed.isEmpty()) request.deny() else request.grant(allowed.toTypedArray())
        }
    }

    BackHandler {
        if (isFullscreen) {
            exitFullscreen()
        } else {
            val wv = webView
            if (wv != null && canGoBack) wv.goBack() else onClose()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exitFullscreen()
            holder.fileCallback?.onReceiveValue(null)
            holder.fileCallback = null
            webView?.apply {
                stopLoading()
                destroy()
            }
            webView = null
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onClose) { Text("Close") } },
                actions = { TextButton(onClick = { webView?.reload() }) { Text("Reload") } },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.allowContentAccess = true
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView,
                                request: WebResourceRequest,
                            ): Boolean = false // keep all navigation inside the app

                            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                                canGoBack = view.canGoBack()
                            }

                            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                                canGoBack = view.canGoBack()
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                progress = newProgress
                            }

                            // File upload
                            override fun onShowFileChooser(
                                webView: WebView,
                                filePathCallback: ValueCallback<Array<Uri>>,
                                fileChooserParams: FileChooserParams,
                            ): Boolean {
                                holder.fileCallback?.onReceiveValue(null)
                                holder.fileCallback = filePathCallback
                                return try {
                                    fileLauncher.launch(fileChooserParams.createIntent())
                                    true
                                } catch (e: Exception) {
                                    holder.fileCallback = null
                                    filePathCallback.onReceiveValue(null)
                                    false
                                }
                            }

                            // Camera / microphone
                            override fun onPermissionRequest(request: PermissionRequest) {
                                val supported = request.resources.filter {
                                    it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                                }
                                if (!isTrustedHost(request.origin.host) || supported.isEmpty()) {
                                    request.deny()
                                    return
                                }
                                val missing = supported.mapNotNull { res ->
                                    when (res) {
                                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
                                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
                                        else -> null
                                    }
                                }.filter { !hasPermission(it) }

                                if (missing.isEmpty()) {
                                    request.grant(supported.toTypedArray())
                                } else {
                                    holder.permissionRequest?.deny()
                                    holder.permissionRequest = request
                                    permissionLauncher.launch(missing.toTypedArray())
                                }
                            }

                            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                                if (holder.permissionRequest == request) holder.permissionRequest = null
                            }

                            // Fullscreen (video player button, element.requestFullscreen())
                            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                                val act = activity
                                if (act == null || holder.customView != null) {
                                    callback.onCustomViewHidden()
                                    return
                                }
                                holder.customView = view
                                holder.customCallback = callback
                                (act.window.decorView as ViewGroup).addView(
                                    view,
                                    FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                    ),
                                )
                                WindowCompat.getInsetsController(act.window, act.window.decorView).apply {
                                    systemBarsBehavior =
                                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                                    hide(WindowInsetsCompat.Type.systemBars())
                                }
                                isFullscreen = true
                            }

                            override fun onHideCustomView() {
                                exitFullscreen()
                            }
                        }
                        loadUrl(url)
                        webView = this
                    }
                },
            )
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                )
            }
        }
    }
}
